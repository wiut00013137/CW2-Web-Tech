module.exports = {
  secret: 'mysecret'
}